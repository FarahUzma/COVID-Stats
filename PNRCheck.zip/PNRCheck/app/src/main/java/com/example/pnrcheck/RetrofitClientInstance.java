package com.example.pnrcheck;

import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Headers;

public class RetrofitClientInstance {

    private static Retrofit retrofit;
    private static final String BASE_URL = "https://covid-193.p.rapidapi.com/statistics";

    public static Retrofit getRetrofitInstance() {
        if (retrofit == null) {
            retrofit = new retrofit2.Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }


    public interface GetDataService {
        @Headers({"x-rapidapi-host : covid-193.p.rapidapi.com","x-rapidapi-key:cr5B3llEK4msh4givsGN9NMjxkQ7p1f80Wkjsne8E8h2qGa6CG"})
        @GET("/")
        Call<StatisticsModel> getStatistics();
    }
}
