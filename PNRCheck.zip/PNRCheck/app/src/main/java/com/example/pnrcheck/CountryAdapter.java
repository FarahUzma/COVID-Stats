package com.example.pnrcheck;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CountryAdapter extends RecyclerView.Adapter<CountryAdapter.CountryViewHolder> {

    private List<StatisticsModel.Response> countryWiseCasesList;

    public CountryAdapter(List<StatisticsModel.Response> countryWiseCasesList){
        this.countryWiseCasesList = countryWiseCasesList;
    }




    @NonNull
    @Override
    public CountryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.country_item_view, parent, false);
        return new CountryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CountryViewHolder holder, int position) {
        holder.countryTitle.setText(countryWiseCasesList.get(position).getCountry());
        holder.activeCasesCount.setText(countryWiseCasesList.get(position).getCases().getActive());
        holder.recoveredCasesCount.setText(countryWiseCasesList.get(position).getCases().getRecovered());
        holder.totalCases.setText(countryWiseCasesList.get(position).getCases().getTotal());
    }

    @Override
    public int getItemCount() {
        return countryWiseCasesList.size();
    }

    public class CountryViewHolder extends RecyclerView.ViewHolder{

        TextView countryTitle;
        TextView activeCasesCount;
        TextView recoveredCasesCount;
        TextView totalCases;
        ImageView thumbnail;


        public CountryViewHolder(@NonNull View itemView) {
            super(itemView);
            countryTitle = itemView.findViewById(R.id.title);
            activeCasesCount =  itemView.findViewById(R.id.active_cases_count);
            recoveredCasesCount = itemView.findViewById(R.id.recovered_cases_count);
            totalCases = itemView.findViewById(R.id.total_cases_count);
            thumbnail =  itemView.findViewById(R.id.thumbnail);
        }

    }
}
